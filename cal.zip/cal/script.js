let displayValue = '';
let operator = '';
let firstOperand = null;

function appendNumber(number) {
    if (displayValue === '0' && number === '0') return;
    displayValue += number;
    updateDisplay();
}

function appendDot() {
    if (!displayValue.includes('.')) {
        displayValue += '.';
    }
    updateDisplay();
}

function operate(op) {
    if (firstOperand === null) {
        firstOperand = parseFloat(displayValue);
        operator = op;
        displayValue = '';
    } else if (displayValue !== '') {
        calculate();
        operator = op;
    }
}

function calculate() {
    if (firstOperand === null || displayValue === '') return;

    const secondOperand = parseFloat(displayValue);
    switch (operator) {
        case 'add':
            firstOperand += secondOperand;
            break;
        case 'subtract':
            firstOperand -= secondOperand;
            break;
        case 'multiply':
            firstOperand *= secondOperand;
            break;
        case 'divide':
            if (secondOperand === 0) {
                displayValue = 'Error';
                updateDisplay();
                return;
            }
            firstOperand /= secondOperand;
            break;
    }

    displayValue = firstOperand.toString();
    operator = '';
    updateDisplay();
}

function clearDisplay() {
    displayValue = '';
    firstOperand = null;
    operator = '';
    updateDisplay();
}

function updateDisplay() {
    document.getElementById('display').textContent = displayValue || '0';
}
